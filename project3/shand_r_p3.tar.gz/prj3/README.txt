Language: Java

Files: Program3.java, Item.java, ItemList.java, badGreedyInput.txt, badImprovedGreedyInput.txt, input.txt, mediumInput.txt, mediumOutputBacktracking.txt, mediumOutputGreedy2.txt, outputBacktracking.txt, outputbadGreedy1.txt, outputbadGreedy2.txt, outputbadImprovedGreedy2.txt, outputGreedy2.txt, smallInput.txt, smallOutputBacktracking.txt, smallOutputGreedy2.txt

Execution:
Please compile the program with the command: javac prj3/*.java
Please run the program with the command: java prj3/Program3.java 'prj3/<inputfile.txt>' '<outputfile.txt>' <algorithm # = 0, 1, or 2>
Please make sure to compile and run the program 2 directory up from where the files are located, or the program will not work.

please email me at rshand1@binghamton.edu if there are any issues trying to run this program
Thank you!
