Language: Java

Files: Program1.java, BaseballCard.java, ProfitInfo.java, market-price.txt, price-list.txt, output.txt

Execution:
Please compile the program with the command: javac prj1/*.java
Please run the program with the command: java prj1/Program1.java -m 'prj1/market-price.txt' -p 'prj1/price-list.txt'
Please make sure to compile and run the program 1 directory up from where the files are located, or the program will not work.

please email me at rshand1@binghamton.edu if there are any issues trying to run this program
Thank you!

